<?php
/**
 * Plugin Name: wpFamily-Enroll
 * Description: Developing a Custom Registration
 * Version: 1.0.0
 * Author: Sanskriti
 * Text Domain: foo-followers
 * Domain Path: /languages/
 */

 // Ensure that this file is being included by a parent file.
 if (!defined('ABSPATH')) {
     exit;
 }
 
 // Include the main plugin class.
 require_once plugin_dir_path(__FILE__) . 'includes/class-wp-family-enroll.php';
 
 // Initialize the plugin.
 add_action('plugins_loaded', array('WP_Family_Enroll', 'init'));
 