<?php

class WP_Family_enroll {

    public static function init() {
        add_action('init', array(__CLASS__, 'register_family_member_post_type'));
        add_action('add_meta_boxes', array(__CLASS__, 'add_family_member_meta_boxes'));
        add_action('save_post_family_member', array(__CLASS__, 'save_family_member_meta_boxes'), 10, 2);
        add_action('add_meta_boxes', array(__CLASS__, 'add_listing_meta_boxes'));
        add_action('save_post_hp_listing', array(__CLASS__, 'save_listing_meta_boxes'), 10, 2);
        add_action('wp_ajax_register_family_member', array(__CLASS__, 'ajax_register_family_member'));
        add_action('wp_ajax_nopriv_register_family_member', array(__CLASS__, 'ajax_register_family_member'));
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_scripts'));
        add_action('hivepress/v1/models/listing/post', array(__CLASS__, 'register_family_member'));
    }

    public static function register_family_member_post_type() {
        register_post_type('family_member', array(
            'labels' => array(
                'name' => __('Family Members', 'wp-family-enroll'),
                'singular_name' => __('Family Member', 'wp-family-enroll')
            ),
            'public' => true,
            'has_archive' => true,
            'supports' => array('title'),
        ));
    }


    public static function add_listing_meta_boxes() {
        add_meta_box(
            'listing_eligibility',
            __('Listing Eligibility Criteria', 'wp-family-enroll'),
            array(__CLASS__, 'render_listing_meta_box'),
            'hp_listing',
            'normal',
            'default'
        );
    }
    
    public static function render_listing_meta_box($post) {
        wp_nonce_field('save_listing_eligibility', 'listing_nonce');
        $eligibility = get_post_meta($post->ID, '_listing_eligibility', true);
        ?>
        <p>
            <label for="listing_age"><?php _e('Age Range', 'wp-family-enroll'); ?></label>
            <input type="text" name="listing_age" id="listing_age" value="<?php echo esc_attr($eligibility['age']); ?>">
            <span><?php _e('Enter age range (e.g., 11-12)', 'wp-family-enroll'); ?></span>
        </p>
        <p>
            <label for="listing_gender"><?php _e('Gender', 'wp-family-enroll'); ?></label>
            <select name="listing_gender" id="listing_gender">
                <option value="male" <?php selected($eligibility['gender'], 'male'); ?>><?php _e('Male', 'wp-family-enroll'); ?></option>
                <option value="female" <?php selected($eligibility['gender'], 'female'); ?>><?php _e('Female', 'wp-family-enroll'); ?></option>
            </select>
        </p>
        <?php
    }
    
    public static function save_listing_meta_boxes($post_id, $post) {
        if (!isset($_POST['listing_nonce']) || !wp_verify_nonce($_POST['listing_nonce'], 'save_listing_eligibility')) {
            return;
        }
    
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
    
        if ($post->post_type != 'hp_listing') {
            return;
        }
    
        $eligibility = array();
        if (isset($_POST['listing_age'])) {
            $eligibility['age'] = sanitize_text_field($_POST['listing_age']);
        }
    
        if (isset($_POST['listing_gender'])) {
            $eligibility['gender'] = sanitize_text_field($_POST['listing_gender']);
        }
    
        update_post_meta($post_id, '_listing_eligibility', $eligibility);
    }
    
    public static function ajax_register_family_member() {
        if (!isset($_POST['listing_id']) || !isset($_POST['family_member_id'])) {
            wp_send_json_error('Invalid data.');
        }

        $listing_id = intval($_POST['listing_id']);
        $family_member_id = intval($_POST['family_member_id']);
        
        // Get the listing post object
        $listing = get_post($listing_id);
        if ($listing && $listing->post_type == 'hp_listing') {
            // Call the register_family_member method
            self::register_family_member($listing, $family_member_id);
            wp_send_json_success('Family member registered successfully.');
        } else {
            wp_send_json_error('Invalid listing.');
        }
    }

    public static function register_family_member($listing, $family_member_id) {
        $eligibility_criteria = get_post_meta($listing->ID, '_listing_eligibility', true);

        $family_member_age = get_post_meta($family_member_id, '_family_member_age', true);
        $family_member_gender = get_post_meta($family_member_id, '_family_member_gender', true);

        // Parse age range from eligibility criteria
        list($min_age, $max_age) = explode('-', $eligibility_criteria['age']);

        if ($family_member_age >= $min_age && $family_member_age <= $max_age && $family_member_gender == $eligibility_criteria['gender']) {
            update_post_meta($listing->ID, '_registered_family_member', $family_member_id);
            echo "Family member registered successfully.";
        } else {
            echo "No eligible family members found.";
        }
    }

    public static function enqueue_scripts() {
        wp_enqueue_script('wp-family-enroll', plugins_url('script.js', __FILE__), array('jquery'), '1.0', true);
    }




  
    public static function register_family_member($listing) {
        $eligibility_criteria = get_post_meta($listing->ID, '_listing_eligibility', true);
    
        // Fetch family members from the database.
        $family_members = new WP_Query(array(
            'post_type' => 'family_member',
            'post_status' => 'publish',
            'meta_query' => array(
                array(
                    'key' => '_family_member_age',
                    'value' => explode('-', $eligibility_criteria['age']),
                    'compare' => 'BETWEEN',
                    'type' => 'NUMERIC'
                ),
                array(
                    'key' => '_family_member_gender',
                    'value' => $eligibility_criteria['gender'],
                    'compare' => '='
                )
            )
        ));
    
        if ($family_members->have_posts()) {
            while ($family_members->have_posts()) {
                $family_members->the_post();
                $family_member_id = get_the_ID();
                // Register the family member for the listing.
                update_post_meta($listing->ID, '_registered_family_member', $family_member_id);
                echo "Family member registered successfully.";
            }
        } else {
            echo "No eligible family members found.";
        }
    
        wp_reset_postdata();
    }
    
}
