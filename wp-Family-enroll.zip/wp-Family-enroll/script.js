jQuery(document).ready(function($) {
    $('.register-family-member').on('click', function(e) {
        e.preventDefault();

        var listingId = $(this).data('listing-id');
        var familyMemberId = $(this).data('family-member-id');

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'register_family_member',
                listing_id: listingId,
                family_member_id: familyMemberId,
            },
            success: function(response) {
                if (response.success) {
                    alert('Family member registered successfully.');
                } else {
                    alert('Registration failed: ' + response.data);
                }
            }
        });
    });
});
